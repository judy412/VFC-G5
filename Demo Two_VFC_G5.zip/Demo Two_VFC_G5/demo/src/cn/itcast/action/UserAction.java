package cn.itcast.action;
import java.util.ArrayList;
import java.util.List;
import cn.itcast.domain.User;
import cn.itcast.service.UserService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
public class UserAction extends ActionSupport implements ModelDriven<User> {
	private static final long serialVersionUID = 1L;
	//��װ����
	private User user = new User();
	private String op = null;
	@Override
	public User getModel() {
		return this.user;
	}
	// *****************************
	public String getOp() {
		return op;
	}
	public void setOp(String op) {
		this.op = op;
	}
	private UserService userService;
	public UserService getUserService() {
		return userService;
	}
	public void setUserService(UserService userService) {
		this.userService=userService;
	}
	public String add() {
		this.userService.saveUser(user);
		return "add";
	}
	public String del() {
		this.userService.deleteUser(this.userService.findUserById(user.getId()));
		return "del";
	}
	public String find() {
		if (op==null||op.equals("")||user.getId()==null){
			List<User> users=this.userService.findAllUser();
			ActionContext ac=ActionContext.getContext();
			ac.put("users", users);
		}else{
			User user1=this.userService.findUserById(user.getId());
			List<User> users=new ArrayList<User>();
			users.add(user1);
			ActionContext ac=ActionContext.getContext();
			ac.put("users", users);
		}
		return "find";
	}
}
