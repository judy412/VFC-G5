package cn.itcast.action;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import cn.itcast.domain.Student;
import cn.itcast.service.StudentService;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
public class StudentAction extends ActionSupport implements ModelDriven<Student>{
	private static final long serialVersionUID = 1L;
	//��װ����
	int pageindex=0;//��ʼҳ
	int pagesize=6;//��ʾÿҳ��������
	private Student student = new Student();
	private String op = null;
	@Override
	public Student getModel() {
		return this.student;
	}
	// *****************************
	public String getOp() {
		return op;
	}
	public void setOp(String op) {
		this.op = op;
	}
	private StudentService studentService;
	public StudentService getStudentService() {
		return studentService;
	}
	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}
	//����ѧ��--
	public String addStudent() {
		this.studentService.saveStudent(student);
		return "addStudent";
	}
	//ɾ��ѧ��--
	public String delStudent() {
		this.studentService.deleteStudent(this.studentService.findStudentByStuId(student.getStuId()));
		return "delStudent";
	}
	//����ѧ��--
	//ѧ�Ų���
	public String findStuByStuId() {
		if (op==null||op.equals("")||student.getStuId()==null){
			List<Student> students=this.studentService.findAllStudnet();
			ActionContext ac=ActionContext.getContext();
			ac.put("students", students);
		}else{
			Student student1=this.studentService.findStudentByStuId(student.getStuId());
			List<Student> students=new ArrayList<Student>();
			students.add(student1);
			ActionContext ac=ActionContext.getContext();
			ac.put("students", students);
		}
		return "findStuByStuId";
	}
	//��������(�ù���δӦ��)
	public String findStuByName() {
		if (op==null||op.equals("")||student.getName()==null){
			List<Student> students=this.studentService.findAllStudnet();
			ActionContext ac=ActionContext.getContext();
			ac.put("students", students);
		}else{
			Student student1=this.studentService.findStudentByName(student.getName());
			List<Student> students=new ArrayList<Student>();
			students.add(student1);
			ActionContext ac=ActionContext.getContext();
			ac.put("students", students);
		}
		return "findStuByName";
	}
	public int getPageindex() {
		return pageindex;
	}
	public void setPageindex(int pageindex) {
		this.pageindex = pageindex;
	}

	public String findStudentByHql() {
		Configuration config = new Configuration().configure();
		SessionFactory sessionFactory = config.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t =  session.beginTransaction();
		String hql = "from Student";
		Query query = session.createQuery(hql);
		query.setFirstResult(pageindex*pagesize);
		query.setMaxResults(pagesize);
		List<Student> list = query.list();
		ActionContext ac = ActionContext.getContext();
		ac.put("ssize", list.size());
		ac.put("students", list);
		t.commit();
		session.close();
		sessionFactory.close();
		return "findStudentByHql";
	}

	public String execute() {
		Configuration config = new Configuration().configure();
		SessionFactory sessionFactory = config.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction t =  session.beginTransaction();
		String hql = "from Student";
		Query query = session.createQuery(hql);
		query.setFirstResult(pageindex*pagesize);
		query.setMaxResults(pagesize);
		List<Student> list = query.list();
		ActionContext ac = ActionContext.getContext();
		ac.put("ssize", list.size());
		ac.put("students", list);
		t.commit();
		session.close();
		sessionFactory.close();
		return SUCCESS;
	}
}
