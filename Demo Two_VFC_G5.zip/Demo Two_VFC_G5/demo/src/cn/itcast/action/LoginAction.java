package cn.itcast.action;
import cn.itcast.dao.IUserDAO;
import cn.itcast.dao.impl.UserDAO;
import cn.itcast.domain.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
public class LoginAction extends ActionSupport{
	private static final long serialVersionUID = 1L;
	private String username;
    private String password;
    //�����û������execute����
    public String execute() throws Exception{
        boolean validated=false;//��֤�ɹ���ʶ
        IUserDAO userDAO=new UserDAO();
        User user=userDAO.validateUser(getUsername(),getPassword());
        ActionContext actionContext = ActionContext.getContext();
        System.out.println("3");
        System.out.println(user);
        System.out.println(actionContext.getSession().put("user", user));
        System.out.println("3");
        if(user!=null)
        {
        	validated=true;
        	System.out.println("4");
            System.out.println(user);
            System.out.println(actionContext.getSession().put("user", user));
            System.out.println("4");
        }
        if(validated)
        {
           //��֤�ɹ������ַ�����success��
            return SUCCESS;
        }
        else
        {
        	actionContext.put("msg", "�û��������벻��ȷ");
        	//��֤ʧ�ܷ����ַ�����error��
            return ERROR;
        }
    }
    public String getUsername(){
        return username;
    }
    public void setUsername(String username){
        this.username=username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    
}