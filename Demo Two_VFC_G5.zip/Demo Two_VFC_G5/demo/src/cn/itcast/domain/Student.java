package cn.itcast.domain;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {

	// Fields

	private String stuId;
	private String name;
	private String type;
	private Integer age;
	private String gender;
	private String class_;
	private String speciality;
	private Integer scoreChinese;
	private Integer scoreMath;
	private Integer scoreEnglish;
	private Integer scoreGeography;
	private Integer scoreHistory;
	private String address;
	private String telephoneNumber;

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** minimal constructor */
	public Student(String name, String type, Integer age, String gender,
			String class_) {
		this.name = name;
		this.type = type;
		this.age = age;
		this.gender = gender;
		this.class_ = class_;
	}

	/** full constructor */
	public Student(String name, String type, Integer age, String gender,
			String class_, String speciality, Integer scoreChinese,
			Integer scoreMath, Integer scoreEnglish, Integer scoreGeography,
			Integer scoreHistory, String address, String telephoneNumber) {
		this.name = name;
		this.type = type;
		this.age = age;
		this.gender = gender;
		this.class_ = class_;
		this.speciality = speciality;
		this.scoreChinese = scoreChinese;
		this.scoreMath = scoreMath;
		this.scoreEnglish = scoreEnglish;
		this.scoreGeography = scoreGeography;
		this.scoreHistory = scoreHistory;
		this.address = address;
		this.telephoneNumber = telephoneNumber;
	}

	// Property accessors

	public String getStuId() {
		return this.stuId;
	}

	public void setStuId(String stuId) {
		this.stuId = stuId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getClass_() {
		return this.class_;
	}

	public void setClass_(String class_) {
		this.class_ = class_;
	}

	public String getSpeciality() {
		return this.speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public Integer getScoreChinese() {
		return this.scoreChinese;
	}

	public void setScoreChinese(Integer scoreChinese) {
		this.scoreChinese = scoreChinese;
	}

	public Integer getScoreMath() {
		return this.scoreMath;
	}

	public void setScoreMath(Integer scoreMath) {
		this.scoreMath = scoreMath;
	}

	public Integer getScoreEnglish() {
		return this.scoreEnglish;
	}

	public void setScoreEnglish(Integer scoreEnglish) {
		this.scoreEnglish = scoreEnglish;
	}

	public Integer getScoreGeography() {
		return this.scoreGeography;
	}

	public void setScoreGeography(Integer scoreGeography) {
		this.scoreGeography = scoreGeography;
	}

	public Integer getScoreHistory() {
		return this.scoreHistory;
	}

	public void setScoreHistory(Integer scoreHistory) {
		this.scoreHistory = scoreHistory;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTelephoneNumber() {
		return this.telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

}