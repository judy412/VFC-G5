package cn.itcast.dao;
import cn.itcast.domain.User;

/**
 * �ӿ�
 * @author Red
 *
 */
public interface IUserDAO {

    public User validateUser(String username,String password);
}