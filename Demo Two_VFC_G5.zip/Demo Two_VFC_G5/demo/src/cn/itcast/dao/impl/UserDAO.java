package cn.itcast.dao.impl;
import hibernate.HibernateSessionFactory;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;

import cn.itcast.dao.IUserDAO;
import cn.itcast.domain.User;

/**
 * ʵ�ֽӿ�
 * @author Red
 *
 */
public class UserDAO  implements IUserDAO{
    public User validateUser(String username,String password){
    	ActionContext actionContext = ActionContext.getContext();
        String sql="from User u where u.username=? and u.password=?";
        org.hibernate.Query query=HibernateSessionFactory.getSession().createQuery(sql);
        query.setParameter(0, username);
        query.setParameter(1, password);
        List<User> users=query.list();
        /*System.out.println("1");
        System.out.println(users);
        System.out.println(actionContext.getSession().put("user", users));
        System.out.println("1");*/
        if(users.size()!=0){
            User user=(User)users.get(0);
            System.out.println("2");
            System.out.println(users);
            System.out.println(actionContext.getSession().put("user", users));
            System.out.println(actionContext.getSession().put("user", users));
            System.out.println("2");
            return user;
        }
        HibernateSessionFactory.closeSession();
        return null;
    }
}