package cn.itcast.dao.impl;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import cn.itcast.dao.StudentDao;
import cn.itcast.domain.Student;
public class StudentDaoImpl implements StudentDao {
	// �ṩhibernateģ��
	private HibernateTemplate hibernateTemplate;
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate=hibernateTemplate;
	}
	//��ѧ������
	public void saveStudent(Student student) {
		this.hibernateTemplate.save(student);
	}
	public void updateStudent(Student student) {
		this.hibernateTemplate.update(student);
	}
	public void deleteStudent(Student student) {
		this.hibernateTemplate.delete(student);
	}
	public Student findStudentByStuId(String stuId) {
		return this.hibernateTemplate.get(Student.class, stuId);
	}
	public Student findStudentByName(String name) {
		return this.hibernateTemplate.get(Student.class, name);
	}
	public List<Student> findAllStudnet() {
		return this.hibernateTemplate.find("from Student");
	}
}
