package cn.itcast.service.impl;
import java.util.List;
import cn.itcast.dao.StudentDao;
import cn.itcast.domain.Student;
import cn.itcast.service.StudentService;
public class StudentServiceImpl implements StudentService{
	private StudentDao studentDao;
	public void setStudentDao(StudentDao studentDao) {
		this.studentDao = studentDao;
	}
	//��ѧ������
	public void saveStudent(Student student) {
		this.studentDao.saveStudent(student);
	}
	public void updateStudent(Student student) {
		this.studentDao.updateStudent(student);
	}
	public void deleteStudent(Student student) {
		this.studentDao.deleteStudent(student);
	}
	public Student findStudentByStuId(String stuId) {
		return this.studentDao.findStudentByStuId(stuId);
	}
	public Student findStudentByName(String name) {
		return this.studentDao.findStudentByName(name);
	}
	public List<Student> findAllStudnet() {
		return this.studentDao.findAllStudnet();
	}
}
