package cn.itcast.service;
import java.util.List;
import cn.itcast.domain.Student;
public interface StudentService {
	//��ѧ������
		public void saveStudent(Student student);

		public void updateStudent(Student student);

		public void deleteStudent(Student student);
		
		public Student findStudentByStuId(String stuId);
		
		public Student findStudentByName(String name);
		
		public List<Student> findAllStudnet();
}
